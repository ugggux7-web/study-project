/* Sprout Strike — original art, level and audio. No assets or dependencies. */
(() => {
'use strict';
const W=960,H=540,WORLD=7680,STEP=1/120,GRAVITY=1300,SPEED=190,JUMP=565,MAX_HP=6;
const $=id=>document.getElementById(id),canvas=$('game'),ctx=canvas.getContext('2d');
ctx.imageSmoothingEnabled=false;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n)), overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const keys=new Set(); let game,muted=false,audioContext,accumulator=0,last=0;
function sound(type){
  if(muted||!audioContext)return;
  const notes={jump:[320,640,.11,'square'],airjump:[480,960,.16,'triangle'],dash:[740,160,.18,'triangle'],bomb:[180,45,.28,'sawtooth'],shot:[170,65,.07,'sawtooth'],coin:[880,1320,.12,'sine'],hurt:[180,50,.23,'sawtooth'],hit:[110,50,.06,'triangle'],power:[550,1100,.25,'triangle'],checkpoint:[440,880,.35,'sine'],win:[523,1046,.5,'triangle']}[type];
  if(!notes)return;
  try{const o=audioContext.createOscillator(),gain=audioContext.createGain(),t=audioContext.currentTime;o.type=notes[3];o.frequency.setValueAtTime(notes[0],t);o.frequency.exponentialRampToValueAtTime(notes[1],t+notes[2]);gain.gain.setValueAtTime(type==='shot'?.035:.065,t);gain.gain.exponentialRampToValueAtTime(.001,t+notes[2]);o.connect(gain);gain.connect(audioContext.destination);o.start(t);o.stop(t+notes[2]);}catch{}
}
function unlockAudio(){try{audioContext ||= new (window.AudioContext||window.webkitAudioContext)();audioContext.resume();}catch{}}
const palettes={
 hero:{o:'#25344d',g:'#398b83',l:'#91e0bd',s:'#ffe1c8',d:'#d59792',w:'#f4faf0',b:'#6484a0',t:'#374867',y:'#eec47e',h:'#6a789d',a:'#b4c9e2',c:'#eebfa7'},
 bug:{o:'#523a4d',r:'#db6480',p:'#ff9ca0',w:'#fff2cf',d:'#903955',y:'#ffd17c'},
 turret:{o:'#323f59',b:'#6a7eb2',l:'#a9c5db',w:'#fff9d2',y:'#f6c97a',d:'#43597f'}
};
const sprites={hero:[
"...............gg.......",".............ggllg......","........ooooogggg.......","......oogggggggooo......",".....oglllllllllggo.....","....oggggggggggggggo....","....oaaaaaaaahhhhaao....","...oawwwaaaaaaaahhao....","...oawwaaaahsssahhao....","...oawaaasssssssahao....","...oaaaasswoswossaho....","...oaahsssysssyssaho....","...ohahssssssssssho.....","...ohhahoosssssohho.....","....ohhaocccccohho......","....ohogggggggggo.......","...oogllllgglllggoo.....","..ogggggggggggggggo.....","...ohobwwwwwwwbohso.....","....oobwwwywwbbooo......",".....obyyyyyybbo........",".....obbbbbbbbbo........",".....oottttttoo.........","......ott.oott..........","......oss..sso..........","......ott..tto..........",".....oott..ttoo.........",".....oooo..oooo........."],
 bug:['...o......o.....','..oro....oro....','...oooooooo.....','..orrprrprro....','.orrpppppprro...','orrrpppppprrro..','orrworrworrro...','orrworrworrro...','.orrryyrrrro....','..orrrrrrro.....','...ooooooo......','..oo.oo.ooo.....'],
 turret:['.....oooo.......','....obbbbo......','...oblllbo......','..obllllbbo.....','.obbbbbbbbbo....','.obwobwobbbbo...','.obwobwobbbbo...','..obbbbbboooo...','..obbybboyyyyo..','..obbbbbboooo...','...odddddo......','..oddoodddo.....','..ooo..oooo.....']};
function sprite(name,x,y,scale=2,dir=1,frame=0,paint=ctx){
  const ctx=paint;
  const rows=sprites[name],pal=palettes[name];ctx.save();ctx.translate(Math.round(x)+(dir<0?rows[0].length*scale:0),Math.round(y));ctx.scale(dir,1);
  for(let yy=0;yy<rows.length;yy++)for(let xx=0;xx<rows[yy].length;xx++){const c=pal[rows[yy][xx]];if(c){ctx.fillStyle=c;let dx=0;if(yy>rows.length-4&&frame)dx=xx<rows[0].length/2?frame:-frame;ctx.fillRect(xx*scale+dx,yy*scale,scale,scale);}}
  ctx.restore();
}
class Game{
 constructor(){this.reset();}
 reset(level=this.level||1){
  this.level=level===2?2:1;this.traps=[];this.chapterScore=0;
  this.state='start';this.t=0;this.time=0;this.camera=0;this.maxX=100;this.score=0;this.coins=0;this.kills=0;this.damageTaken=0;this.checkpoint=false;this.checkX=95;this.shake=0;this.toastTime=0;this.bullets=[];this.hostile=[];this.particles=[];this.texts=[];this.items=[];this.coinsList=[];this.enemies=[];this.solids=[];this.platforms=[];this.blocks=[];this.bombs=[];this.explosions=[];this.relics=[{x:2570,y:145,w:23,h:28,taken:false},{x:5505,y:192,w:23,h:28,taken:false},{x:6058,y:169,w:23,h:28,taken:false}];this.relicCount=0;this.chest={x:2560,y:180,w:38,h:30,opened:false};this.p={x:95,y:420,w:26,h:40,vx:0,vy:0,dir:1,hp:MAX_HP,grounded:false,ground:null,coyote:0,jumpBuffer:0,airRequest:false,airJumps:1,dashTimer:0,dashCooldown:0,dashDir:1,bombCooldown:0,inv:0,power:0,star:0,cooldown:0,burst:0,burstTimer:0};
  const ground=[[0,1430],[1560,2060],[2350,2800],[2940,3320],[3480,4200],[4330,4840],[4980,5460],[5610,6090],[6230,WORLD]];
  for(const [x,end] of ground)this.solids.push({x,y:460,w:end-x,h:100,type:'ground'});
  const ledges=[ [490,374,125],[720,306,120],[1050,367,120], [1750,376,140],[1885,294,120],[2025,218,130],[2200,218,140],[2390,210,110],[2510,210,150], [2230,397,110],[2440,376,110],[2650,370,100],[2970,373,130],[3120,290,100],[3510,368,135],[3690,302,130], [4420,364,125],[4600,288,145],[5050,369,120],[5230,293,130],[5660,361,140],[5870,285,150],[6280,371,120],[6510,363,120], [6820,362,110],[7160,362,110] ];
  for(const [x,y,w]of ledges)this.platforms.push({x,y,w,h:18,type:'platform',dx:0});
  this.platforms.push({x:2090,y:414,w:108,h:18,type:'moving',baseX:2120,baseY:414,amp:65,axis:'x',speed:.9,phase:0,dx:0});
  this.platforms.push({x:3325,y:406,w:104,h:18,type:'moving',baseX:3350,baseY:400,amp:38,axis:'y',speed:1.1,phase:1.2,dx:0});
  for(const [x,y,w,type]of [[5320,238,94,'platform'],[5430,238,140,'platform'],[5650,222,100,'crumble'],[5810,194,95,'crumble'],[5980,214,145,'platform'],[2870,244,90,'crumble'],[3015,214,100,'platform']])this.platforms.push({x,y,w,h:18,type,dx:0,dy:0,trigger:0,respawn:0});
  this.cracked=[{x:5370,y:106,w:36,h:160,type:'cracked',broken:false}];this.solids.push(...this.cracked);
  this.spring={x:5945,y:446,w:42,h:14,type:'spring',bounce:0};this.solids.push(this.spring);
  const rewardBlocks=[[580,330],[620,330],[1115,338],[1690,333],[2590,332],[3600,265],[4500,325],[4660,332],[5150,325],[5800,323],[6400,328]];
  for(const [x,y]of rewardBlocks){const b={x,y,w:36,h:36,type:'reward',used:false,bump:0};this.blocks.push(b);this.solids.push(b);}
  for(const [x,y]of [[540,330],[660,330],[1079,338],[1151,338],[2554,332],[2626,332],[4624,332],[4696,332],[6364,328],[6436,328]])this.solids.push({x,y,w:36,h:36,type:'brick'});
  // A discreet, optional block is only revealed by a head bump.
  this.blocks.push({x:900,y:318,w:36,h:36,type:'hidden',used:false,bump:0});
  const row=(x,y,n,space=33)=>{for(let i=0;i<n;i++)this.coinsList.push({x:x+i*space,y,w:18,h:22,taken:false});};
  row(270,410,5);row(506,341,3);row(742,273,3);row(1080,410,4);row(1390,340,3);row(1780,343,3);row(1905,261,3);row(2045,185,3);row(2222,185,3);row(2405,177,2);row(2490,335,3);row(2658,337,3);row(2977,340,4);row(3130,257,2);row(3530,335,3);row(3710,269,3);row(4080,410,3);row(4440,331,3);row(4620,255,3);row(5055,336,3);row(5240,260,3);row(5678,328,3);row(5880,252,4);row(6295,338,3);row(6518,330,3);row(7390,410,6);
  row(2877,211,2);row(3030,181,2);row(5440,203,2);row(5660,189,2);row(5825,161,2);row(5990,181,2);
  this.items.push({x:1250,y:420,w:26,h:28,type:'power',taken:false},{x:4025,y:420,w:26,h:28,type:'heart',taken:false},{x:5360,y:420,w:26,h:28,type:'power',taken:false},{x:6630,y:419,w:26,h:28,type:'heart',taken:false});
  const add=(type,x,left,right,y=0)=>{this.enemies.push({type,x,y:y|| (type==='bug'?432:428),w:30,h:type==='bug'?28:32,hp:type==='bug'?2:3,maxHp:type==='bug'?2:3,left,right,dir:-1,speed:type==='bug'?43:23,cooldown:1.5+(x%13)/10,flash:0,dead:false,windup:0});};
  add('bug',945,875,1020);add('bug',1640,1590,1790);add('turret',1930,1850,2000);add('bug',2510,2390,2670);add('bug',3040,2960,3280);add('turret',3200,3090,3260);add('bug',3650,3500,3810);add('turret',3810,3750,3900);
  add('bug',4470,4350,4550);add('turret',4710,4590,4800);add('turret',4660,4610,4700,256);add('bug',5070,5000,5240);add('bug',5310,5170,5390);add('turret',5320,5235,5325,261);add('turret',5390,5300,5410);add('bug',5720,5630,5860);add('turret',5980,5860,6040);add('turret',5940,5880,5970,253);add('bug',6330,6260,6490);add('turret',6510,6430,6570);
  this.totalEnemies=this.enemies.length+1;
  this.boss={x:7060,y:378,w:94,h:82,hp:96,maxHp:96,active:false,dead:false,phase:'idle',timer:1.5,cycle:0,flash:0,dir:-1,shots:0,shotTimer:0};
  this.gate={x:7290,y:314,w:26,h:146,type:'gate'};
  if(this.level===2)this.buildSecondLevel();
  keys.clear();$('toast').classList.remove('show');$('toast').textContent='';this.renderUI();this.showOverlay('start');
 }
 buildSecondLevel(){
  const data=JSON.parse(JSON.stringify(window.SPROUT_LEVEL2));
  this.solids=data.ground.map(([x,end])=>({x,y:460,w:end-x,h:100,type:'ground'}));
  this.platforms=data.platforms.map(([x,y,w])=>({x,y,w,h:18,type:'platform',dx:0,dy:0}));
  this.platforms.push(...data.moving,...data.crumble.map(([x,y,w])=>({x,y,w,h:18,type:'crumble',dx:0,dy:0,trigger:0,respawn:0})));
  this.blocks=data.blocks.map(([x,y])=>({x,y,w:36,h:36,type:'reward',used:false,bump:0}));this.solids.push(...this.blocks);
  this.blocks.push({x:740,y:329,w:36,h:36,type:'hidden',used:false,bump:0});
  this.cracked=data.cracked;this.spring=data.spring;this.solids.push(...this.cracked,this.spring);
  this.coinsList=[];for(const [x,y,n]of data.coins)for(let i=0;i<n;i++)this.coinsList.push({x:x+i*33,y,w:18,h:22,taken:false});
  this.enemies=data.enemies.map(([type,x,left,right,y])=>({type,x,y:y||(type==='bug'?432:428),w:30,h:type==='bug'?28:32,hp:type==='bug'?2:3,maxHp:type==='bug'?2:3,left,right,dir:-1,speed:type==='bug'?49:25,cooldown:1.6+(x%11)/10,flash:0,dead:false,windup:0}));
  this.relics=data.relics;this.chest=data.chest;this.items=data.items;this.traps=data.traps;this.totalEnemies=this.enemies.length+1;
  Object.assign(this.boss,{hp:120,maxHp:120,targetX:7000,fromX:7060});
 }
 updateTraps(){for(const trap of this.traps){const phase=(this.t+trap.offset)%4.8;trap.phase=phase<2.6?'idle':phase<3.4?'warning':'active';if(trap.phase==='active'&&overlap(this.p,{x:trap.x,y:trap.y-92,w:trap.w,h:92}))this.hurt(false,trap.x+trap.w/2);}}
 updateCrystalBoss(dt,oldY){
  const b=this.boss,p=this.p;if(b.dead)return;b.flash=Math.max(0,b.flash-dt);
  if(!b.active){if(p.x<=6720)return;b.active=true;b.phase='rest';b.timer=2;this.notify('晶翼守卫：避开地面标记，跃击后有攻击破绽！');}
  b.timer-=dt;
  if(b.phase==='rest'&&b.timer<=0){b.phase='windup';b.timer=1.2;b.fromX=b.x;b.targetX=clamp(p.x-32,6750,7160);}
  else if(b.phase==='windup'&&b.timer<=0){b.phase='leap';b.timer=.95;}
  else if(b.phase==='leap'){const u=clamp(1-b.timer/.95,0,1);b.x=b.fromX+(b.targetX-b.fromX)*u;b.y=378-Math.sin(u*Math.PI)*145;if(b.timer<=0){b.y=378;b.phase='recover';b.timer=2.1;this.shake=.3;this.emit(b.x+47,454,'#bbd7ff',24);for(const dir of [-1,1])this.hostile.push({x:b.x+47,y:442,w:22,h:17,vx:dir*210,vy:0,life:3.7,type:'wave'});}}
  else if(b.phase==='recover'&&b.timer<=0){b.phase='volley';b.timer=2.7;b.shots=b.hp<60?5:3;b.shotTimer=.35;}
  else if(b.phase==='volley'){b.shotTimer-=dt;if(b.shots>0&&b.shotTimer<=0){b.shots--;b.shotTimer=.52;const dx=p.x+13-b.x-47,dy=p.y+20-b.y-30,len=Math.hypot(dx,dy)||1;this.hostile.push({x:b.x+47,y:b.y+30,w:12,h:12,vx:dx/len*175,vy:dy/len*175,life:4,type:'crystal'});}if(b.timer<=0){b.phase='rest';b.timer=1.65;b.cycle++;}}
  if(overlap(p,b)){if(p.vy>0&&oldY+p.h<=b.y+17&&b.phase!=='windup'){this.damageEnemy(b,true);p.y=b.y-p.h;p.vy=-450;p.grounded=false;}else this.hurt(false,b.x+b.w/2);}
 }
 start(){this.state='playing';this.showOverlay(null);keys.clear();canvas.focus();}
 togglePause(){if(this.state==='playing'){this.state='paused';keys.clear();this.showOverlay('paused');}else if(this.state==='paused'){this.state='playing';this.showOverlay(null);canvas.focus();}}
 notify(text){this.toastTime=3.3;$('toast').textContent=text;$('toast').classList.add('show');}
 emit(x,y,color,count=10){for(let i=0;i<count;i++)this.particles.push({x,y,vx:(Math.random()-.5)*170,vy:-40-Math.random()*170,life:.3+Math.random()*.4,max:.7,color,size:2+Math.random()*3});}
 label(text,x,y,color='#fff3bc'){this.texts.push({text,x,y,life:1.1,color});}
 addCoin(x,y,n=1){this.coins+=n;this.score+=n*100;sound('coin');this.emit(x,y,'#ffda65',8);this.label(`+${n*100}`,x,y);}
 reward(b){if(b.used)return;b.used=true;b.bump=.18;if(b.type==='hidden'){this.solids.push(b);this.notify('发现秘密！星光护盾 · 8 秒');}this.emit(b.x+18,b.y,'#ffe3a3',12);const roll=b.type==='hidden'?.99:Math.random();if(roll<.5){this.addCoin(b.x+18,b.y,3);}else{this.items.push({x:b.x+6,y:b.y-28,w:24,h:26,type:roll<.8?'heart':'star',taken:false,vy:-110,vx:38});}sound('power');}
 hurt(pit=false,sourceX=null){
  const p=this.p;if(this.state!=='playing'||(!pit&&(p.inv>0||p.star>0)))return;
  p.hp--;this.damageTaken++;p.inv=2;p.burst=0;this.shake=.25;sound('hurt');this.emit(p.x+13,p.y+20,'#ff9780',16);
  if(p.hp<=0){this.state='dead';keys.clear();this.showOverlay('dead');this.renderUI();return;}
  if(pit){this.respawn();this.notify('落入深坑 · 返回营地，生命 −1');}else{p.vx=(p.x+13<(sourceX??p.x)?-1:1)*210;p.vy=-200;p.grounded=false;}
 }
 respawn(){const p=this.p;p.x=this.checkX;p.y=418;p.vx=0;p.vy=0;p.inv=2.5;p.grounded=false;p.ground=null;p.coyote=0;p.jumpBuffer=0;p.airJumps=1;p.airRequest=false;p.dashTimer=0;this.bombs=[];this.explosions=[];this.hostile=[];this.bullets=[];this.camera=clamp(p.x-W*.35,0,WORLD-W);if(this.boss.active&&!this.boss.dead){Object.assign(this.boss,{active:false,x:7060,y:378,phase:'idle',timer:1.5});}}
 shoot(){const p=this.p;this.bullets.push({x:p.dir>0?p.x+p.w+7:p.x-15,y:p.y+21,w:12,h:5,vx:p.dir*620,life:1.35});sound('shot');this.emit(p.x+(p.dir>0?39:-10),p.y+22,'#fff0ad',3);}
 requestJump(){const p=this.p;p.jumpBuffer=.14;p.airRequest=!p.grounded&&p.coyote<=0;}
 dash(){const p=this.p;if(this.state!=='playing'||p.dashCooldown>0)return;p.dashTimer=.18;p.dashCooldown=1.4;p.dashDir=p.dir;p.inv=Math.max(p.inv,.24);p.vy=0;sound('dash');this.emit(p.x+13,p.y+20,'#c5f2c1',16);}
 throwBomb(){const p=this.p;if(this.state!=='playing'||p.bombCooldown>0)return;p.bombCooldown=4.5;this.bombs.push({x:p.x+13+p.dir*20,y:p.y+13,w:14,h:14,vx:p.dir*330,vy:-220,fuse:.72});sound('power');}
 explode(b){this.explosions.push({x:b.x+7,y:b.y+7,life:.34});this.emit(b.x+7,b.y+7,'#e6efa0',28);this.shake=.2;sound('bomb');
  for(const e of [...this.enemies,this.boss])if(!e.dead&&(e!==this.boss||e.active)&&Math.hypot(e.x+e.w/2-b.x,e.y+e.h/2-b.y)<108+e.w/2){if(e===this.boss&&e.phase==='windup'){this.emit(e.x+40,e.y,'#ffe994',8);continue;}e.hp=Math.max(0,e.hp-(e===this.boss?10:5));e.flash=.16;if(e.hp===0)this.kill(e);}
  for(const wall of this.cracked)if(!wall.broken&&Math.hypot(clamp(b.x,wall.x,wall.x+wall.w)-b.x,clamp(b.y,wall.y,wall.y+wall.h)-b.y)<110){wall.broken=true;this.solids=this.solids.filter(s=>s!==wall);this.score+=200;this.emit(wall.x+18,wall.y+80,'#aeb999',35);this.notify('石墙崩塌了！探索遗迹密室 →');}
 }
 kill(e){if(e.dead)return;e.dead=true;this.kills++;this.score+=e===this.boss?2500:250;this.emit(e.x+e.w/2,e.y+e.h/2,e===this.boss?'#b9dc8d':'#f6a5a2',e===this.boss?45:16);this.label(e===this.boss?'+2500':'+250',e.x,e.y);sound('hit');if(e===this.boss){this.hostile=[];this.notify(this.level===2?'晶翼守卫已击败！进入月辉星门 →':'铁壳队长已击败！前往灯塔 →');this.items.push({x:7220,y:424,w:24,h:26,type:'heart',taken:false});}}
 damageEnemy(e,stomp=false){if(e.dead)return;if(e===this.boss&&e.phase==='windup'){this.emit(e.x+e.w/2,e.y+40,'#fff1a9',4);return;}e.hp=Math.max(0,e.hp-(stomp?(e===this.boss?6:99):1));e.flash=.10;sound('hit');this.emit(e.x+e.w/2,e.y+e.h/2,'#fff1c0',4);if(e.hp<=0)this.kill(e);}
 update(dt){
  if(this.state!=='playing')return;
  this.time+=dt;this.t+=dt;const p=this.p;this.maxX=Math.max(this.maxX,p.x);this.shake=Math.max(0,this.shake-dt);this.toastTime-=dt;if(this.toastTime<=0)$('toast').classList.remove('show');
  for(const b of this.blocks)b.bump=Math.max(0,b.bump-dt);this.spring.bounce=Math.max(0,this.spring.bounce-dt);
  for(const q of this.platforms){let oldX=q.x,oldY=q.y;if(q.type==='moving'){if(q.axis==='x')q.x=q.baseX+Math.sin(this.t*q.speed+q.phase)*q.amp;else q.y=q.baseY+Math.sin(this.t*q.speed+q.phase)*q.amp;}q.dx=q.x-oldX;q.dy=q.y-oldY;if(q.respawn>0){q.respawn-=dt;if(q.respawn<=0){q.respawn=0;q.trigger=0;}}if(q.type==='crumble'&&q.trigger>0&&q.respawn<=0){q.trigger+=dt;if(q.trigger>.65){q.respawn=3.5;q.trigger=0;this.emit(q.x+q.w/2,q.y,'#c6b991',12);if(p.ground===q){p.ground=null;p.grounded=false;}}}if(p.ground===q){p.x+=q.dx;p.y+=q.dy;}}
  p.inv=Math.max(0,p.inv-dt);p.star=Math.max(0,p.star-dt);p.power=Math.max(0,p.power-dt);p.dashTimer=Math.max(0,p.dashTimer-dt);p.dashCooldown=Math.max(0,p.dashCooldown-dt);p.bombCooldown=Math.max(0,p.bombCooldown-dt);p.cooldown-=dt;p.jumpBuffer=Math.max(0,p.jumpBuffer-dt);p.coyote=p.grounded?.11:Math.max(0,p.coyote-dt);
  const input=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
  const target=input*SPEED,accel=p.grounded?1450:1000;p.vx+=clamp(target-p.vx,-accel*dt,accel*dt);if(input)p.dir=input;
  if(p.jumpBuffer>0&&p.coyote>0){p.vy=-JUMP;p.jumpBuffer=0;p.coyote=0;p.grounded=false;p.ground=null;sound('jump');this.emit(p.x+13,p.y+40,'#e7edb7',5);}
  else if(p.jumpBuffer>0&&p.airRequest&&p.airJumps>0){p.vy=-520;p.airJumps--;p.jumpBuffer=0;p.airRequest=false;p.dashTimer=0;sound('airjump');this.emit(p.x+13,p.y+40,'#d8f9ba',20);this.label('二段跳',p.x-9,p.y+48,'#e7fac0');}
  if(p.dashTimer>0){p.vx=p.dashDir*650;p.vy=0;}
  if(keys.has('KeyJ')&&p.cooldown<=0){this.shoot();p.cooldown=p.power>0?.40:.29;if(p.power>0){p.burst=2;p.burstTimer=.08;}}
  if(p.burst>0){p.burstTimer-=dt;if(p.burstTimer<=0){this.shoot();p.burst--;p.burstTimer=.08;}}
  let solids=this.boss.dead?this.solids:[...this.solids,this.gate];
  p.x+=p.vx*dt;p.x=clamp(p.x,0,WORLD-p.w);
  for(const s of solids)if(overlap(p,s)){if(p.vx>0)p.x=s.x-p.w;else if(p.vx<0)p.x=s.x+s.w;p.vx=0;}
  const oldY=p.y;p.vy=Math.min(p.vy+(p.dashTimer>0?0:GRAVITY*dt),780);p.y+=p.vy*dt;p.grounded=false;p.ground=null;
  for(const s of solids){if(!overlap(p,s))continue;if(p.vy>=0&&oldY+p.h<=s.y+2){p.y=s.y-p.h;p.vy=0;p.grounded=true;p.ground=s;}else if(p.vy<0&&oldY>=s.y+s.h-2){p.y=s.y+s.h;p.vy=0;if(s.type==='reward')this.reward(s);}}
  if(p.vy>=0)for(const s of this.platforms)if(!(s.respawn>0)&&p.x+p.w>s.x&&p.x<s.x+s.w&&oldY+p.h<=s.y+Math.abs(s.dy)+2&&p.y+p.h>=s.y){p.y=s.y-p.h;p.vy=0;p.grounded=true;p.ground=s;if(s.type==='crumble'&&s.trigger===0)s.trigger=.001;}
  if(p.grounded){p.airJumps=1;p.airRequest=false;if(p.ground===this.spring){p.vy=-810;p.grounded=false;p.ground=null;p.coyote=0;this.spring.bounce=.3;sound('airjump');this.emit(p.x+13,p.y+40,'#d3e89c',15);}}
  for(const b of this.blocks)if(b.type==='hidden'&&!b.used&&p.vy<0&&p.x+p.w>b.x&&p.x<b.x+b.w&&oldY>=b.y+b.h&&p.y<b.y+b.h){p.y=b.y+b.h;p.vy=0;this.reward(b);}
  if(p.y>H+100){this.hurt(true);if(this.state!=='playing')return;}
  if(!this.checkpoint&&p.x>3920&&p.x<4140&&p.y>350){this.checkpoint=true;this.checkX=3970;p.hp=MAX_HP;sound('checkpoint');this.emit(3970,400,'#e9f8a1',30);this.notify('营地已激活 · 生命回满 · 掉坑从这里继续');}
  for(const c of this.coinsList)if(!c.taken&&overlap(p,c)){c.taken=true;this.addCoin(c.x,c.y);}
  for(const item of this.items){if(item.taken)continue;if(item.vy!==undefined){const prev=item.y;item.x+=(item.vx||0)*dt;item.vy+=GRAVITY*dt;item.y+=item.vy*dt;for(const s of [...solids,...this.platforms])if(overlap(item,s)&&prev+item.h<=s.y+3){item.y=s.y-item.h;item.vy=0;if(s.type==='ground')item.vx=0;}if(item.y>640){item.taken=true;continue;}}if(overlap(p,item)){item.taken=true;sound('power');this.emit(item.x,item.y,'#e2faaa',15);if(item.type==='heart'){if(p.hp<MAX_HP){p.hp++;this.label('生命 +1',p.x,p.y);}else{this.score+=150;this.label('+150',p.x,p.y);} }else if(item.type==='power'){p.power=20;this.notify('三连发已就绪 · 20 秒 · 按住 J 射击');}else{p.star=8;this.notify('星光护盾 · 8 秒无敌');}}}
  if(!this.chest.opened&&overlap(p,this.chest)){this.chest.opened=true;this.addCoin(this.chest.x,this.chest.y,15);p.power=25;this.score+=500;this.notify('云端宝箱！金币 +15 · 三连发 25 秒');sound('power');}
  for(const relic of this.relics)if(!relic.taken&&overlap(p,relic)){relic.taken=true;this.relicCount++;this.score+=750;p.hp=Math.min(MAX_HP,p.hp+1);sound('checkpoint');this.emit(relic.x,relic.y,'#b5fcdf',28);this.notify(`晴空晶种 ${this.relicCount}/3 · 分数 +750 · 恢复 1 格生命`);if(this.relicCount===3){this.score+=2000;p.power=30;this.notify('三枚晶种集齐！探索奖励 +2000 · 三连发 30 秒');}}
  this.updateTraps();this.updateEnemies(dt,oldY);this.updateBoss(dt,oldY);
  for(const b of this.bombs){b.fuse-=dt;b.vy+=750*dt;b.x+=b.vx*dt;b.y+=b.vy*dt;if(this.solids.some(s=>overlap(b,s))||this.enemies.some(e=>!e.dead&&overlap(b,e))||(!this.boss.dead&&this.boss.active&&overlap(b,this.boss)))b.fuse=0;if(b.fuse<=0)this.explode(b);}this.bombs=this.bombs.filter(b=>b.fuse>0);
  for(const e of this.explosions)e.life-=dt;this.explosions=this.explosions.filter(e=>e.life>0);
  for(const b of this.bullets){b.life-=dt;b.x+=b.vx*dt;if(solids.some(s=>overlap(b,s))){b.life=0;this.emit(b.x,b.y,'#f4d5a0',3);continue;}for(const e of [...this.enemies,this.boss]){if(e.dead||(e===this.boss&&!e.active))continue;if(overlap(b,e)){this.damageEnemy(e);b.life=0;break;}}}
  this.bullets=this.bullets.filter(b=>b.life>0);
  for(const b of this.hostile){b.life-=dt;b.x+=b.vx*dt;b.y+=b.vy*dt;if(solids.some(s=>overlap(b,s)))b.life=0;if(b.life>0&&overlap(p,b)){this.hurt(false,b.x);b.life=0;}}
  this.hostile=this.hostile.filter(b=>b.life>0);
  for(const f of this.particles){f.life-=dt;f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=450*dt;}this.particles=this.particles.filter(f=>f.life>0);
  for(const f of this.texts){f.life-=dt;f.y-=25*dt;}this.texts=this.texts.filter(f=>f.life>0);
  if(this.state==='playing'&&this.boss.dead&&p.x>7500){this.state='won';this.score+=p.hp*500+Math.max(0,Math.round(180-this.time)*10);sound('win');keys.clear();this.showOverlay('won');}
  const cameraTarget=clamp(p.x-W*.35,0,WORLD-W);this.camera+=(cameraTarget-this.camera)*(1-Math.exp(-dt*6));
 }
 updateEnemies(dt,oldY){
  const p=this.p;
  for(const e of this.enemies){if(e.dead)continue;e.flash=Math.max(0,e.flash-dt);if(Math.abs(e.x-p.x)>700)continue;
   if(e.type==='bug'||e.windup<=0){e.x+=e.dir*e.speed*dt;if(e.x<e.left){e.x=e.left;e.dir=1;}if(e.x>e.right){e.x=e.right;e.dir=-1;}}
   if(e.type==='turret'){
    e.cooldown-=dt;if(e.cooldown<=0&&Math.abs(e.x-p.x)<470&&Math.abs(e.y-p.y)<190){e.windup=.55;e.cooldown=2.8;e.dir=p.x<e.x?-1:1;}
    if(e.windup>0){e.windup-=dt;if(e.windup<=0){const dx=p.x+13-e.x-15,dy=p.y+22-e.y-15,len=Math.hypot(dx,dy)||1;this.hostile.push({x:e.x+15,y:e.y+15,w:11,h:11,vx:dx/len*155,vy:dy/len*155,life:4,type:'seed'});}}
   }
   if(overlap(p,e)){if(p.star>0){this.kill(e);}else if(p.vy>0&&oldY+p.h<=e.y+12){this.damageEnemy(e,true);p.y=e.y-p.h;p.vy=-410;p.grounded=false;p.coyote=0;}else this.hurt(false,e.x+e.w/2);}
  }
 }
 updateBoss(dt,oldY){
  if(this.level===2){this.updateCrystalBoss(dt,oldY);return;}
  const b=this.boss,p=this.p;if(b.dead)return;b.flash=Math.max(0,b.flash-dt);
  if(!b.active){if(p.x>6720){b.active=true;b.phase='rest';b.timer=2;this.notify('铁壳队长：红光预警后冲撞，跳上平台躲避！');}else return;}
  b.timer-=dt;
  if(b.phase==='rest'&&b.timer<=0){b.phase='windup';b.timer=1.15;b.dir=p.x<b.x?-1:1;}
  else if(b.phase==='windup'&&b.timer<=0){b.phase='charge';b.timer=1.05;this.shake=.12;}
  else if(b.phase==='charge'){b.x=clamp(b.x+b.dir*290*dt,6725,7180);if(b.timer<=0){b.phase='recover';b.timer=1.6;}}
  else if(b.phase==='recover'&&b.timer<=0){b.phase='volley';b.timer=2.2;b.shots=3;b.shotTimer=.2;}
  else if(b.phase==='volley'){
   b.shotTimer-=dt;if(b.shots>0&&b.shotTimer<=0){b.shots--;b.shotTimer=.65;const dir=p.x<b.x?-1:1;this.hostile.push({x:b.x+b.w/2,y:427,w:15,h:15,vx:dir*210,vy:0,life:4,type:'orb'});if(b.hp<b.maxHp/2)this.hostile.push({x:b.x+b.w/2,y:376,w:13,h:13,vx:dir*180,vy:0,life:4,type:'orb'});}
   if(b.timer<=0){b.phase='rest';b.timer=1.7;b.cycle++;}
  }
  if(overlap(p,b)){if(p.vy>0&&oldY+p.h<=b.y+17&&b.phase!=='windup'){this.damageEnemy(b,true);p.y=b.y-p.h;p.vy=-450;p.grounded=false;}else this.hurt(false,b.x+b.w/2);}
 }
 renderUI(){
  const p=this.p;$('hearts').innerHTML=Array.from({length:MAX_HP},(_,i)=>`<span class="${i<p.hp?'':'empty'}">♥</span>`).join(' ');$('hearts').setAttribute('aria-label',`${p.hp} 格生命`);$('coins').textContent=String(this.coins).padStart(3,'0');$('score').textContent=String(this.score).padStart(5,'0');$('clock').textContent=formatTime(this.time);
  $('weapon').innerHTML=p.power>0?`三连发 <b>${Math.ceil(p.power)}s</b>`:'基础枪 <b>∞</b>';if(p.star>0)$('weapon').innerHTML+=` · 护盾 ${Math.ceil(p.star)}s`;
  $('air-status').textContent=p.airJumps>0?'就绪':'已用';$('jump-skill').classList.toggle('cooling',p.airJumps===0);
  for(const [name,remaining,max]of [['dash',p.dashCooldown,1.4],['bomb',p.bombCooldown,4.5]]){$(`${name}-status`).textContent=remaining>0?`${remaining.toFixed(1)}s`:'就绪';$(`${name}-cooldown`).style.width=`${remaining/max*100}%`;$(`${name}-skill`).classList.toggle('cooling',remaining>0);}
  $('relic-count').textContent='◆'.repeat(this.relicCount)+'◇'.repeat(3-this.relicCount);
  const z=p.x<1750?0:p.x<3920?1:p.x<6720?2:3;$('zone-no').textContent=`0${z+1}`;$('zone').textContent=(this.level===2?['蓝晶林地','悬空矿桥','月辉深谷','星门祭坛']:['风铃草甸','云间栈道','失落遗迹','晴空前哨'])[z];$('progress').style.width=`${Math.min(100,this.maxX/7500*100)}%`;$('checkpoint-label').textContent=this.checkpoint?'⚑ 营地已激活':'营地未激活';
  $('viewport').classList.toggle('night',this.level===2);
  $('stage-title').textContent=this.level===2?'月辉矿谷':'晴空前哨';$('edition-stage').textContent=`第 0${this.level} 关 / 共 2 关`;$('island-name').textContent=this.level===2?'月辉谷':'晴空岛';$('boss-name').textContent=this.level===2?'晶翼守卫':'铁壳队长';
  $('boss-hud').hidden=!this.boss.active||this.boss.dead||this.state==='start';$('boss-fill').style.width=`${Math.max(0,this.boss.hp/this.boss.maxHp*100)}%`;$('boss-phase').textContent={rest:'正在观察 · 可以攻击',windup:'！蓄力冲撞 · 护甲生效',charge:'冲撞中 · 跳跃躲避',recover:'硬直破绽 · 全力攻击',volley:'种子弹幕 · 注意高低弹',leap:'跃击中 · 离开标记区域'}[this.boss.phase]||'警戒中';
  if(this.level===2)$('boss-phase').textContent={rest:'正在观察 · 可以攻击',windup:'落点标记 · 跃击预警',leap:'跃击中 · 离开标记区域',recover:'落地硬直 · 全力攻击',volley:'追踪瞄准 · 移动躲避'}[this.boss.phase]||'警戒中';
  $('mission').textContent=this.level===2?(this.boss.dead?'任务：进入星门，完成双关冒险 →':'任务：穿过月辉矿谷，唤醒星门'):this.boss.dead?'任务：进入灯塔，前往第二关 →':'任务：穿过晴空岛，点亮前哨灯塔';$('pause').setAttribute('aria-label',this.state==='paused'?'继续游戏':'暂停游戏');
 }
 showOverlay(mode){
  const o=$('overlay'),panel=$('panel');o.hidden=!mode;if(!mode)return;o.className=mode==='start'?'overlay start-overlay':'overlay';
  if(mode==='start')panel.innerHTML='<div class="kicker">SPROUT STRIKE / TWO CHAPTERS</div><h2>小小芽芽。<br><em>大大冒险。</em></h2><p>星叶游侠芽芽，出发寻找新的光。<br>6 格生命 · 二段跳 · 叶影冲刺 · 种子爆弹</p><div class="chapter-select"><button id="chapter-one" type="button">01 晴空前哨</button><button id="chapter-two" type="button">02 月辉矿谷</button></div><div class="hero-portrait"><canvas id="portrait" width="144" height="160" aria-label="银蓝短发、薄荷贝雷帽与短披肩的女游侠芽芽"></canvas><span>芽芽 · 星叶游侠</span></div><button class="primary" id="main-action">出发冒险 <span aria-hidden="true">→</span></button><div class="start-meta"><span>✦ 每关约 3–5 分钟</span><span>3 枚隐藏晶种</span><span>K 冲刺 · L 爆弹</span></div>';
  if(mode==='paused')panel.innerHTML='<div class="kicker">TAKE A LITTLE BREATHER</div><h2>在这里歇一会。</h2><p>冒险已暂停，计时和强化也会暂停。<br>准备好了，就继续向前吧。</p><button class="primary" id="main-action">继续冒险 →</button><button class="secondary" id="restart-action">重新挑战本关</button><button class="secondary" id="home-action">返回关卡选择</button>';
  if(mode==='dead')panel.innerHTML=`<div class="kicker">EVERY SPROUT GROWS STRONGER</div><h2>再试一次吧。</h2><p>下次一定能走得更远。<br>空中再按空格补救，K 冲刺可短暂闪避伤害。</p><div class="results"><div class="result"><small>本次分数</small><b>${this.score}</b></div><div class="result"><small>探索进度</small><b>${Math.min(100,Math.round(this.maxX/7500*100))}%</b></div></div><button class="primary" id="main-action">重新挑战 ↻</button><button class="secondary" id="home-action">返回开始画面</button>`;
  if(mode==='won'){const stars=1+(this.coins>=45?1:0)+(this.chest.opened&&this.relicCount===3&&this.kills>=14?1:0);panel.innerHTML=`<div class="kicker">MISSION COMPLETE</div><h2>${this.level===2?'星门，为你开启！':'晴空，再次闪耀！'}</h2><div class="stars" aria-label="${stars} 星评价">${'★'.repeat(stars)}<span style="opacity:.25">${'★'.repeat(3-stars)}</span></div><div class="results"><div class="result"><small>收集金币</small><b>${this.coins}</b></div><div class="result"><small>击败怪物</small><b>${this.kills} / ${this.totalEnemies}</b></div><div class="result"><small>冒险用时</small><b>${formatTime(this.time)}</b></div><div class="result"><small>总分</small><b>${this.score}</b></div></div><p class="relic-results" style="font-size:13px;margin-bottom:10px">晴空晶种 ${this.relicCount} / 3 · ${this.chest.opened?'已发现秘密宝箱':'秘密宝箱未发现'}</p><p style="font-size:12px;margin-bottom:15px">★ 完成关卡　★ 金币 ≥45<br>★ 找到宝箱、集齐 3 枚晶种且击败 ≥14 只怪物</p><button class="primary" id="main-action">${this.level===1?'进入第二关：月辉矿谷 →':'重新挑战第二关 ↻'}</button><button class="secondary" id="home-action">返回关卡选择</button>`;}
  if(mode==='start'){for(const [id,n]of [['chapter-one',1],['chapter-two',2]]){$(id).setAttribute('aria-pressed',String(this.level===n));$(id).onclick=()=>this.reset(n);}renderPortrait();}
  $('main-action').onclick=()=>{unlockAudio();if(mode==='paused')this.togglePause();else if(mode==='start')this.start();else if(mode==='won'&&this.level===1){this.reset(2);this.start();this.notify('第二关 · 月辉矿谷 · 生命已回满');}else{this.reset();this.start();}};
  if($('restart-action'))$('restart-action').onclick=()=>{this.reset();this.start();};if($('home-action'))$('home-action').onclick=()=>this.reset();
 }
}
function formatTime(time){return `${String(Math.floor(time/60)).padStart(2,'0')}:${String(Math.floor(time%60)).padStart(2,'0')}`;}
function renderPortrait(){const c=$('portrait');if(!c)return;const paint=c.getContext('2d');paint.clearRect(0,0,144,160);paint.imageSmoothingEnabled=false;paint.fillStyle='#24494670';paint.fillRect(30,136,90,7);sprite('hero',24,12,4,1,0,paint);paint.fillStyle='#263b52';paint.fillRect(94,85,35,11);paint.fillStyle='#badfd8';paint.fillRect(96,87,32,5);paint.fillStyle='#f5d992';paint.fillRect(126,88,9,5);}

// All scene graphics are drawn in crisp pixel units, with layered silhouettes.
const C={ink:'#244c42',grass:'#88be52',light:'#d1e890',dirt:'#ba8251',darkDirt:'#99613f'};
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function poly(points,color){ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(...points[0]);for(let i=1;i<points.length;i++)ctx.lineTo(...points[i]);ctx.closePath();ctx.fill();}
function cloud(x,y,s=1){ctx.save();ctx.translate(Math.round(x),Math.round(y));ctx.scale(s,s);rect(0,12,98,20,'#daf3db');rect(14,2,63,34,'#f7fbe3');rect(27,-8,34,40,'#f7fbe3');rect(-9,17,117,10,'#f7fbe3');rect(9,30,90,7,'#b9e6d0');ctx.restore();}
function tree(x,y,s=1,t=0){ctx.save();ctx.translate(x,y);ctx.scale(s,s);rect(-7,-88,15,90,'#776544');rect(-3,-80,5,80,'#ab8951');rect(-25,-66,22,7,'#776544');rect(-24,-84,7,23,'#776544');const sway=Math.round(Math.sin(t+x)*2);rect(-46+sway,-123,90,39,'#459971');rect(-33+sway,-151,62,79,'#459971');rect(-55+sway,-126,80,30,'#64af72');rect(-36+sway,-146,47,55,'#78bd79');rect(-22+sway,-154,36,13,'#a1d187');rect(-48+sway,-109,22,8,'#a1d187');rect(24+sway,-102,14,9,'#337e62');rect(-12+sway,-134,7,7,'#cfe493');ctx.restore();}
function bush(x,y,s=1){ctx.save();ctx.translate(x,y);ctx.scale(s,s);rect(-24,-16,48,16,'#478e5c');rect(-15,-25,30,25,'#65a65f');rect(-3,-29,17,10,'#8abd6b');rect(-20,-13,7,5,'#90c274');rect(11,-15,8,5,'#a2cd76');ctx.restore();}
function flower(x,y,t,color='#fff2bd'){const sway=Math.round(Math.sin(t*2+x)*2);rect(x,y-13,2,13,'#447a50');rect(x-5,y-7,6,3,'#588e50');rect(x-3+sway,y-19,8,8,color);rect(x-5+sway,y-17,12,4,color);rect(x+sway,y-17,3,3,'#e7b74e');}
function coinArt(x,y,t,scale=1){const w=(5+Math.abs(Math.cos(t*4+x*.07))*10)*scale;rect(x+9-w/2,y+3,w,16*scale,'#bb8644');rect(x+7-w/2,y,w,18*scale,'#ffda64');rect(x+9-w/2,y+3,Math.max(2,w-4),12*scale,'#f3b54d');rect(x+9-w/2,y+3,2,10*scale,'#fff2a2');}
function itemArt(item,t){const{x,y,type}=item;const bob=Math.sin(t*3+x)*3;ctx.save();ctx.translate(x,y+bob);rect(-4,-4,34,36,'#f8ffd12b');if(type==='heart'){poly([[12,6],[7,1],[1,1],[-2,5],[-2,12],[12,24],[26,12],[26,5],[23,1],[17,1]],'#7e4d48');poly([[12,9],[6,4],[2,4],[1,7],[1,11],[12,21],[23,11],[23,7],[21,4],[18,4]],'#fc8a7c');rect(3,6,5,4,'#ffdac1');}else if(type==='power'){rect(0,0,26,26,'#205a63');rect(3,3,20,20,'#72d6d3');poly([[14,2],[5,15],[12,15],[9,24],[22,10],[15,10],[20,2]],'#fff4ae');}else{poly([[12,-2],[17,7],[27,9],[20,16],[22,26],[12,21],[2,26],[4,16],[-3,9],[7,7]],'#ffe280');rect(8,10,3,5,'#617459');rect(16,10,3,5,'#617459');}ctx.restore();}
function sign(x,y,line1,line2){rect(x+26,y+35,7,51,'#86744b');rect(x,y,114,42,'#715d41');rect(x+3,y+3,108,34,'#eadaac');rect(x+7,y+7,2,2,'#9f8757');rect(x+103,y+7,2,2,'#9f8757');ctx.fillStyle='#4c6042';ctx.font='bold 12px "Microsoft YaHei",sans-serif';ctx.textAlign='center';ctx.fillText(line1,x+57,y+17);ctx.font='10px "Microsoft YaHei",sans-serif';ctx.fillText(line2,x+57,y+31);ctx.textAlign='left';}
function building(x,t,won){
 rect(x+7,307,129,153,'#3e6b5d');rect(x+14,313,115,147,'#eee4b2');rect(x+22,319,98,139,'#fff1c5');
 for(let yy=336;yy<455;yy+=28)for(let xx=20+(yy%56===0?0:14);xx<117;xx+=30)rect(x+xx,yy,23,2,'#dfd3a0');
 rect(x+48,195,48,118,'#f8ebba');rect(x+42,197,60,9,'#487d70');rect(x+45,181,54,18,'#315e58');rect(x+51,153,42,30,'#b2e3c7');rect(x+56,158,32,23,won?'#fff8a9':'#588885');rect(x+50,146,45,8,'#315e58');
 poly([[x+42,147],[x+59,128],[x+83,128],[x+103,147]],'#ec8664');rect(x+62,118,15,11,'#db744f');rect(x+68,100,4,19,'#486954');
 poly([[x-5,316],[x+15,286],[x+58,286],[x+75,278],[x+121,286],[x+150,316]],'#497966');rect(x-5,315,155,9,'#305a4e');rect(x+11,290,110,7,'#78a271');
 rect(x+56,381,43,79,'#2e5a52');rect(x+60,385,35,70,won?'#b6dea0':'#56877c');rect(x+65,390,24,62,'#234941');rect(x+83,421,4,4,'#efd483');
 for(const xx of [29,108]){rect(x+xx-9,342,19,26,'#527e6b');rect(x+xx-5,346,11,18,'#abd9cb');rect(x+xx,346,3,18,'#527e6b');rect(x+xx-5,352,11,3,'#527e6b');}
 rect(x+136,348,4,109,'#5f7653');poly([[x+140,349],[x+178,354+Math.sin(t*3)*3],[x+171,371],[x+140,367]],won?'#fce183':'#81b88a');rect(x-20,455,181,6,'#386653');
 if(won){ctx.globalAlpha=.18;poly([[x+72,162],[x-180,83],[x-180,245]],'#ffffbd');poly([[x+72,162],[x+300,72],[x+300,239]],'#ffffbd');ctx.globalAlpha=1;}
}
function bossArt(b,t){
 const x=b.x,y=b.y;ctx.save();ctx.translate(Math.round(x),Math.round(y));if(b.flash>0)ctx.globalAlpha=.45;
 const step=b.phase==='charge'?Math.sin(t*23)*5:Math.sin(t*3)*2;
 rect(9,65,27,16,'#264d4b');rect(61,65,27,16,'#264d4b');rect(12,67+step,22,13,'#739684');rect(63,67-step,22,13,'#739684');
 rect(10,11,76,55,'#284e47');rect(3,26,90,33,'#284e47');rect(15,5,66,57,'#6e9874');rect(9,24,78,34,'#709d74');rect(20,9,55,12,'#b3ce8b');rect(14,27,19,26,'#a1bf80');rect(35,22,47,30,'#507e68');
 for(let yy=27;yy<50;yy+=9)rect(42,yy,33,3,'#284e47');
 rect(13,20,24,16,'#294c46');rect(16,23,7,8,b.phase==='windup'?'#ff7257':'#ffe18f');rect(28,23,7,8,b.phase==='windup'?'#ff7257':'#ffe18f');
 rect(-8,41,31,16,'#2f514c');rect(-13,45,11,9,'#9ab5a0');rect(-14,48,8,3,'#29413d');rect(77,38,18,22,'#335c50');rect(82,42,14,11,'#e5be78');
 rect(42,-5,10,15,'#365e4b');rect(39,-10,16,9,b.phase==='windup'?'#ff6a57':'#ffcf6b');
 for(const [xx,yy]of [[20,13],[73,15],[13,50],[78,53]]){rect(xx,yy,4,4,'#d4e3a2');}
 if(b.phase==='windup'){rect(-19,1,6,17,'#ff6c50');rect(-19,22,6,5,'#ff6c50');ctx.globalAlpha=.22+Math.sin(t*25)*.12;rect(-20,79,120,4,'#ff654f');}ctx.restore();
}
function ruinArch(x,y,width,height,t){
 const stone='#708d79',light='#a7b895',shade='#416657';
 rect(x+21,y+20,width-42,height-20,'#38665469');rect(x,y+34,28,height-34,stone);rect(x+width-28,y+34,28,height-34,stone);rect(x+22,y+13,width-44,25,stone);rect(x+44,y,width-88,18,light);rect(x+20,y+12,24,29,light);rect(x+width-44,y+12,24,29,light);
 for(let yy=y+43;yy<y+height;yy+=27){rect(x+3,yy,22,3,shade);rect(x+width-25,yy,22,3,shade);rect(x+3,yy+4,5,17,light);rect(x+width-24,yy+4,5,17,light);}rect(x-7,y+height-10,42,12,shade);rect(x+width-35,y+height-10,42,12,shade);
 for(let i=0;i<7;i++){const xx=x+25+i*24;rect(xx,y+14,3,22+(i%3)*13,'#4b8b60');rect(xx-4,y+28+(i%3)*13,10,5,'#84ad70');}
 for(const xx of [x+37,x+width-45]){rect(xx,y+height-59,8,29,'#54654c');rect(xx-3,y+height-66,14,9,'#e3bd6b');rect(xx,y+height-75-Math.sin(t*9)*3,8,15,'#ffe69b');rect(xx+2,y+height-77,4,8,'#fff1c1');}
}
function relicArt(r,t){const x=r.x+11,y=r.y+13+Math.sin(t*2.5+r.x)*4;ctx.globalAlpha=.16;rect(x-20,y-17,40,34,'#ddfff0');ctx.globalAlpha=1;poly([[x,y-16],[x+12,y-3],[x+8,y+9],[x,y+16],[x-8,y+9],[x-12,y-3]],'#356f66');poly([[x,y-12],[x+8,y-2],[x+5,y+7],[x,y+12],[x-7,y-2]],'#a8f0dc');poly([[x,y-12],[x,y+11],[x-7,y-2]],'#e0ffe2');rect(x-2,y-6,3,9,'#f5ffe8');for(let i=0;i<3;i++){const a=t+i*Math.PI*2/3;rect(x+Math.cos(a)*22,y+Math.sin(a)*17,2,2,'#e2fff2');}}
function crystal(x,y,w,h,bright=false){poly([[x-w/2,y-h*.7],[x,y-h],[x+w/2,y-h*.72],[x+w*.38,y],[x-w*.33,y]],bright?'#72d3dd':'#496b97');poly([[x,y-h],[x+w/2,y-h*.72],[x+w*.38,y],[x,y-h*.1]],bright?'#b7f4e6':'#7792b4');poly([[x-w/2,y-h*.7],[x,y-h],[x,y-h*.1],[x-w*.33,y]],bright?'#83b6e3':'#536b94');rect(x-2,y-h*.75,3,h*.31,bright?'#e4fff2':'#acc8d7');}
function drawNightBackground(g){const c=g.camera,t=g.t;const gradient=ctx.createLinearGradient(0,0,0,H);gradient.addColorStop(0,'#1b284a');gradient.addColorStop(.55,'#3a5279');gradient.addColorStop(1,'#95b9b6');ctx.fillStyle=gradient;ctx.fillRect(0,0,W,H);
 for(let i=0;i<65;i++){ctx.globalAlpha=.4+(Math.sin(t*.7+i)*.25);rect((i*137.7-c*.07+W*4)%W,25+(i*59)%210,i%4===0?3:2,i%4===0?3:2,'#e0ecdb');}ctx.globalAlpha=1;
 rect(742-c*.025,61,42,47,'#e1ebd4');rect(736-c*.025,70,53,29,'#e1ebd4');rect(753-c*.025,55,35,38,'#1f2e50');
 for(let i=-1;i<7;i++){const x=i*218-(c*.2%218);poly([[x,425],[x+20,288],[x+54,288],[x+78,179],[x+112,229],[x+139,245],[x+182,324],[x+218,425]],'#36496e');crystal(x+99,381,58,180);}
 for(let i=-1;i<9;i++){const x=i*165-(c*.4%165);poly([[x,480],[x,349],[x+23,349],[x+23,306],[x+64,306],[x+64,331],[x+100,331],[x+100,391],[x+145,391],[x+165,480]],'#486b80');crystal(x+52,459,26,75);}
 rect(0,482,W,58,'#365d80');for(let i=0;i<30;i++)rect((i*53-c*.4+t*8)%990,497+(i%4)*9,25,2,'#78a1b9');
}
function starGate(x,t,open){ruinArch(x,277,155,183,t);rect(x+42,311,71,146,'#263d5c');for(let i=0;i<5;i++){ctx.globalAlpha=open?.25:.08;rect(x+48+i*5,320+i*8,58-i*10,128-i*16,open?'#a5f5e7':'#7a91bd');}ctx.globalAlpha=1;crystal(x+78,300,38,60,open);for(const xx of [x+13,x+140]){rect(xx-4,363,8,92,'#314b64');crystal(xx,372,23,38,true);}if(open)for(let i=0;i<9;i++){const a=t+i;rect(x+55+(i*17)%52,335+((t*26+i*19)%111),3,3,'#cfffee');}}
function sentinelArt(b,t){const x=b.x,y=b.y;ctx.save();ctx.translate(Math.round(x),Math.round(y));ctx.globalAlpha=b.flash>0?.4:1;for(const dir of [-1,1]){const bx=47+dir*41,flap=Math.sin(t*4)*4;poly([[bx,22],[bx+dir*34,3+flap],[bx+dir*26,45+flap],[bx,61]],'#546ca1');poly([[bx+dir*4,25],[bx+dir*27,10+flap],[bx+dir*19,37+flap]],'#b3dcf0');rect(28+dir*23,67,24,13,'#536c94');rect(29+dir*23,67,19,6,'#9dbfd4');}poly([[47,-3],[81,15],[87,50],[65,73],[27,73],[7,47],[14,15]],'#334c76');poly([[47,2],[75,20],[75,46],[61,64],[30,64],[18,44],[20,21]],'#779cba');poly([[47,4],[69,23],[47,51],[26,23]],'#c9f9ed');poly([[47,7],[47,50],[27,23]],'#9dd4ed');rect(31,32,31,14,'#283e65');rect(35,35,7,6,b.phase==='windup'?'#ffbc95':'#c4fbef');rect(51,35,7,6,b.phase==='windup'?'#ffbc95':'#c4fbef');rect(40,56,15,5,'#c0d4e0');crystal(47,5,16,20,true);ctx.restore();}
function draw(g){
 const t=g.t,camera=g.camera,p=g.p,night=g.level===2;
 if(night)drawNightBackground(g);else{
 const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#70cdd8');sky.addColorStop(.62,'#b6e8d4');sky.addColorStop(1,'#eff3bc');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 // Sun and clouds keep their pixel silhouette, even on high-density displays.
 rect(761-camera*.025,57,38,38,'#f9edaa');rect(755-camera*.025,64,50,24,'#f9edaa');
 for(let i=-1;i<8;i++){const xx=i*255-((camera*.12)%255);cloud(xx+35,80+(i%3)*34,.75+(i%2)*.25);}
 for(let i=-2;i<8;i++){const x=i*245-((camera*.22)%245);poly([[x,365],[x,279],[x+25,279],[x+25,235],[x+56,235],[x+56,196],[x+92,196],[x+92,177],[x+125,177],[x+125,207],[x+153,207],[x+153,241],[x+181,241],[x+181,291],[x+245,291],[x+245,365]],'#8bcbaf');rect(x+57,235,13,100,'#a2d7b8');rect(x+94,190,18,67,'#b4ddbd');}
 for(let i=-2;i<8;i++){const x=i*215-((camera*.37)%215);poly([[x,434],[x,350],[x+23,350],[x+23,315],[x+45,315],[x+45,282],[x+69,282],[x+69,261],[x+103,261],[x+103,286],[x+135,286],[x+135,313],[x+166,313],[x+166,355],[x+215,355],[x+215,434]],'#68b68b');rect(x+46,312,11,75,'#79c297');}
 for(let i=-1;i<10;i++)tree(i*173-(camera*.57%173),457,.7,t*.5);
 rect(0,483,960,57,'#7bc4ad');for(let i=0;i<30;i++)rect((i*53-camera*.4+t*10)%990,497+(i%4)*9,25,2,'#acdccc');}
 ctx.save();ctx.translate(-Math.round(camera)+(g.shake>0?Math.sin(t*110)*g.shake*16:0),g.shake>0?Math.cos(t*97)*g.shake*6:0);
 if(!night&&camera>W*3){ruinArch(4500,167,236,293,t);ruinArch(5135,136,400,324,t);ruinArch(5690,127,285,333,t);rect(5410,103,159,134,'#2c554ee6');rect(5406,99,168,10,'#aec398');rect(5410,103,6,133,'#7b9b7a');rect(5567,103,6,133,'#7b9b7a');for(let xx=5428;xx<5565;xx+=26){rect(xx,119,12,4,'#9ec19a');rect(xx+4,126,4,18,'#6b947c');}rect(5485,231,67,8,'#b6cba1');}
 if(night){for(const x of [170,780,1450,2260,2810,3510,4140,4750,5340,5900,6500])if(x>camera-100&&x<camera+W+100){crystal(x,457,44,92,true);crystal(x+28,457,22,54);crystal(x-24,457,18,39,true);}if(camera>4000&&camera<5350){ruinArch(4780,108,280,352,t);rect(4850,112,140,97,'#2e42617d');}for(let i=0;i<18;i++){const xx=Math.floor(camera/110)*110+i*73;ctx.globalAlpha=.55;rect(xx,220+Math.sin(t*.5+i)*80+(i%3)*40,2,2,'#a9fae0');}ctx.globalAlpha=1;}
 for(const s of g.solids){if(s.type!=='ground'||s.x+s.w<camera-50||s.x>camera+W+50)continue;
  rect(s.x,s.y,s.w,s.h,night?'#526b80':C.dirt);rect(s.x,s.y+18,s.w,5,night?'#344d65':'#86613f');
  for(let y=s.y+28;y<H;y+=24)for(let x=s.x+((y%48)/24)*13;x<s.x+s.w-10;x+=30){rect(x+4,y,15,4,'#ce995f');rect(x+9,y+5,9,4,'#a76e45');rect(x+1,y+13,4,3,'#916443');}
  rect(s.x,s.y,s.w,12,night?'#4a7a80':'#45794d');rect(s.x,s.y-5,s.w,10,night?'#88c8c3':'#9dc960');rect(s.x,s.y-5,s.w,3,night?'#c7ebe0':'#d6e88f');for(let x=s.x;x<s.x+s.w-8;x+=18)rect(x+3,s.y+5,9,8,night?'#63999b':'#6a9f50');
  for(let x=s.x+38;x<s.x+s.w-40;x+=127){bush(x,455,.7+(x%3)*.16);flower(x+42,455,t,x%2?'#fff1bf':'#f5a393');rect(x+63,449,2,8,'#5a934c');rect(x+67,445,2,12,'#5a934c');}
 }
 if(!night)for(const x of [150,820,1680,2720,3590,4120,4800,5530,6130,6650])if(x>camera-100&&x<camera+W+100)tree(x,456,.8,t);
 for(const s of g.platforms){if(s.x+s.w<camera-20||s.x>camera+W+20)continue;if(s.respawn>0){ctx.globalAlpha=.25;for(let xx=s.x;xx<s.x+s.w;xx+=14)rect(xx,s.y,8,3,'#e5f0c3');ctx.globalAlpha=1;continue;}rect(s.x,s.y,s.w,s.h,'#577665');rect(s.x,s.y,s.w,5,s.type==='moving'?'#b6d7a0':s.type==='crumble'?'#edce8c':'#bce07b');rect(s.x+4,s.y+6,s.w-8,8,s.type==='moving'?'#618e80':'#aa9260');for(let xx=s.x+8;xx<s.x+s.w-5;xx+=20)rect(xx,s.y+6,3,10,'#607451');if(s.type==='moving'){rect(s.x+8,s.y+19,s.w-16,4,'#cfddd0');ctx.fillStyle='#eaf1cd';ctx.font='bold 12px monospace';ctx.fillText(s.axis==='x'?'↔':'↕',s.x+s.w/2-5,s.y+13);}else if(s.type==='crumble'){poly([[s.x+25,s.y],[s.x+38,s.y+5],[s.x+32,s.y+10],[s.x+44,s.y+18]],'#6e6349');if(s.trigger>0)for(let i=0;i<4;i++)rect(s.x+15+i*19,s.y+18+Math.sin(t*23+i)*3,3,3,'#eedbb0');}else{rect(s.x+11,s.y+18,5,7,'#729b55');rect(s.x+s.w-17,s.y+18,5,11,'#729b55');}}
 for(const wall of g.cracked){if(wall.broken)continue;rect(wall.x,wall.y,wall.w,wall.h,'#486c5a');for(let yy=wall.y;yy<wall.y+wall.h;yy+=26){rect(wall.x+3,yy+2,30,22,'#a6b293');rect(wall.x+5,yy+4,26,3,'#d6d9ab');}poly([[wall.x+19,wall.y],[wall.x+12,wall.y+32],[wall.x+23,wall.y+50],[wall.x+10,wall.y+77],[wall.x+22,wall.y+103],[wall.x+14,wall.y+135],[wall.x+23,wall.y+160],[wall.x+19,wall.y+132],[wall.x+27,wall.y+102],[wall.x+16,wall.y+77],[wall.x+28,wall.y+50],[wall.x+17,wall.y+30]],'#496d5b');ctx.font='bold 12px "Microsoft YaHei"';ctx.fillStyle='#f3f1c1';ctx.fillText('L 炸开裂纹墙',wall.x-21,wall.y-12);}
 const spring=g.spring;rect(spring.x+5,spring.y+5,32,9,'#426655');for(let i=0;i<3;i++)rect(spring.x+9+i*10,spring.y+3,5,10,'#d6d995');rect(spring.x,spring.y-(spring.bounce>0?7:0),42,6,'#d7f09c');rect(spring.x+5,spring.y-(spring.bounce>0?7:0),32,2,'#f7f2bc');
 for(const b of g.solids){if(!['brick','reward','hidden'].includes(b.type)||b.x>camera+W||b.x+b.w<camera)continue;const yy=b.y-(b.bump?Math.sin(b.bump/.18*Math.PI)*8:0);rect(b.x,yy,36,36,'#855d42');rect(b.x+2,yy+2,32,31,b.used?'#ac9869':b.type==='brick'?'#d69b63':'#ffd270');rect(b.x+3,yy+3,30,3,b.used?'#c4b184':'#ffe5a0');if(b.type==='brick'){rect(b.x+2,yy+17,32,3,'#986342');rect(b.x+16,yy+3,3,14,'#986342');rect(b.x+9,yy+20,3,13,'#986342');rect(b.x+27,yy+20,3,13,'#986342');}else if(!b.used){ctx.font='bold 25px monospace';ctx.fillStyle='#a77035';ctx.fillText('?',b.x+11,yy+27);rect(b.x+4,yy+28,3,3,'#b58043');rect(b.x+29,yy+28,3,3,'#b58043');}else{rect(b.x+7,yy+9,4,4,'#85774d');rect(b.x+25,yy+9,4,4,'#85774d');}}
 // A few floating motes are the clue to the invisible reward block.
 const secret=g.blocks.find(b=>b.type==='hidden');if(!secret.used)for(let i=0;i<3;i++){ctx.globalAlpha=.45+.35*Math.sin(t*3+i);rect(secret.x+8+i*8,secret.y+24+Math.sin(t*2+i)*5,2,2,'#fffbd1');}ctx.globalAlpha=1;
 if(!night){sign(220,374,'A / D 移动 →','空格可二段跳');sign(780,374,'J 发射 · K 冲刺','踩头也能打败怪物');sign(1290,374,'前方深坑 ↗','二段跳 + 冲刺补救');sign(1780,374,'向上探索 ↑','云间藏着宝箱与晶种');sign(3835,374,'前方：休息营地','激活旗帜，生命回满');sign(5040,374,'遗迹密室 ↑','L 爆弹可炸开裂纹墙');sign(5790,374,'风芽弹床 →','寻找高处的晴空晶种');sign(6550,374,'前方：铁壳队长','红光蓄力，跳跃躲避');}else{sign(220,374,'月辉矿谷 →','新旅途 · 二段跳与冲刺');sign(1290,374,'晶能喷口 →','黄光预警，光柱会伤人');sign(2130,374,'晶矿高路 ↑','上方藏着宝箱与晶种');sign(3835,374,'前方：休息营地','激活旗帜，生命回满');sign(4490,374,'封印矿室 ↑','用爆弹打开裂纹石墙');sign(5780,374,'风芽弹床 →','借力跃上星光石台');sign(6510,374,'晶翼守卫 →','躲开落点，再攻击硬直');}
 // Checkpoint camp: pennant, tent and a tiny camp lamp.
 rect(3960,338,5,120,'#557a5c');poly([[3965,341],[4010,348],[4000,370],[3965,365]],g.checkpoint?'#ffdc73':'#c0d2bd');rect(3954,334,17,7,'#ebdb96');poly([[3995,457],[4030,405],[4070,457]],'#779c67');poly([[3995,457],[4030,405],[4038,457]],'#c8d590');poly([[4021,457],[4032,430],[4041,457]],'#496d56');if(g.checkpoint){rect(3974,428,12,18,'#d5ba70');rect(3977,431,6,9,'#fff0a6');}
 const chest=g.chest;rect(chest.x,chest.y+11,38,20,'#684f3d');rect(chest.x+3,chest.y+13,32,16,'#c48a51');rect(chest.x,chest.y+(chest.opened?-9:2),38,13,'#6f593d');rect(chest.x+3,chest.y+(chest.opened?-6:5),32,7,'#f0c878');rect(chest.x+6,chest.y+12,4,18,'#f2cd7e');rect(chest.x+29,chest.y+12,4,18,'#f2cd7e');rect(chest.x+16,chest.y+14,7,9,'#ffe5a1');if(!chest.opened){ctx.font='bold 11px "Microsoft YaHei"';ctx.fillStyle='#345f53';ctx.fillText('秘密补给',chest.x-5,chest.y-9);}
 for(const c of g.coinsList)if(!c.taken&&c.x>camera-30&&c.x<camera+W+30)coinArt(c.x,c.y+Math.sin(t*3+c.x*.01)*3,t);
 for(const item of g.items)if(!item.taken&&item.x>camera-30&&item.x<camera+W+30)itemArt(item,t);
 for(const r of g.relics)if(!r.taken&&r.x>camera-30&&r.x<camera+W+30)relicArt(r,t);
 if(night)starGate(7420,t,g.boss.dead);else building(7440,t,g.boss.dead);
 if(!g.boss.dead){rect(7288,310,8,150,'#436458');rect(7310,310,8,150,'#436458');for(let y=326;y<456;y+=16){rect(7296,y,14,7,'#ecb971');rect(7296,y+7,14,4,'#987651');}rect(7284,303,38,16,'#537766');rect(7295,305,15,12,'#d8c27a');rect(7299,307,6,6,'#6d775b');}
 for(const e of g.enemies){if(e.dead||e.x+e.w<camera-30||e.x>camera+W+30)continue;ctx.globalAlpha=e.flash>0?.35:1;sprite(e.type,e.x-1,e.y+(e.type==='bug'?4:6)+Math.sin(t*7+e.x)*1.5,2,e.dir,Math.sin(t*12)>0?1:0);ctx.globalAlpha=1;if(e.windup>0){rect(e.x+12,e.y-15,4,9,'#ffe8ad');rect(e.x+12,e.y-4,4,3,'#ffe8ad');}if(e.hp<e.maxHp){rect(e.x,e.y-6,e.w,3,'#536750');rect(e.x,e.y-6,e.w*e.hp/e.maxHp,3,'#ffd579');}}
 if(!g.boss.dead){if(night)sentinelArt(g.boss,t);else bossArt(g.boss,t);}
 for(const trap of g.traps){rect(trap.x-4,453,trap.w+8,7,'#334a65');for(let i=0;i<4;i++)crystal(trap.x+5+i*12,455,9,14,true);if(trap.phase==='warning'){ctx.globalAlpha=.22+.1*Math.sin(t*18);rect(trap.x,368,trap.w,88,'#ffdca0');ctx.globalAlpha=1;ctx.fillStyle='#ffeab8';ctx.font='bold 15px monospace';ctx.fillText('!',trap.x+21,358);}if(trap.phase==='active'){ctx.globalAlpha=.62;rect(trap.x,368,trap.w,85,'#87dce9');ctx.globalAlpha=1;for(let i=0;i<4;i++){rect(trap.x+6+i*12,373+(Math.sin(t*20+i)*4),4,80,'#d6fff4');}}}
 if(night&&g.boss.phase==='windup'&&g.boss.active&&!g.boss.dead){ctx.globalAlpha=.3+.15*Math.sin(t*17);rect(g.boss.targetX-8,454,110,6,'#ffccba');ctx.globalAlpha=1;ctx.font='bold 14px monospace';ctx.fillStyle='#ffe4bc';ctx.fillText('▼',g.boss.targetX+40,447);}
 if(p.star>0){ctx.globalAlpha=.22+.06*Math.sin(t*15);ctx.fillStyle='#fff9b8';ctx.beginPath();ctx.arc(p.x+13,p.y+19,31,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
 if(p.dashTimer>0){for(let i=1;i<=4;i++){ctx.globalAlpha=.26-i*.045;sprite('hero',p.x-8-p.dashDir*i*18,p.y-9,1.75,p.dir,0);}ctx.globalAlpha=1;}
 if(!(p.inv>0&&p.dashTimer<=0&&Math.floor(t*14)%2)){
  sprite('hero',p.x-8,p.y-9,1.75,p.dir,p.grounded&&Math.abs(p.vx)>10?(Math.sin(t*18)>0?2:-2):0);
  const gx=p.dir>0?p.x+20:p.x-13;rect(gx,p.y+21,22,9,'#244c4b');rect(gx+2,p.y+22,18,4,p.power>0?'#f4d36e':'#8ec9bc');rect(p.dir>0?gx+19:gx-3,p.y+23,6,4,'#eff0be');rect(p.dir>0?gx+2:gx+14,p.y+29,5,5,'#4b756a');
 }
 for(const b of g.bullets){rect(b.x-(b.vx>0?7:-7),b.y+1,9,3,'#fff3b469');rect(b.x,b.y,b.w,b.h,'#fff8c5');rect(b.x+(b.vx>0?8:0),b.y+1,4,3,'#ffc85b');}
 for(const b of g.hostile){rect(b.x-2,b.y+2,b.w+4,b.h-4,'#965f62');rect(b.x,b.y,b.w,b.h,b.type==='orb'?'#f9a566':'#e99197');rect(b.x+2,b.y+2,4,4,'#ffe2ac');}
 for(const b of g.bombs){rect(b.x-2,b.y+3,18,10,'#34695c');rect(b.x+1,b.y,12,16,'#34695c');rect(b.x+2,b.y+2,9,9,'#daf0a4');rect(b.x+4,b.y-5,6,5,'#6daf6c');rect(b.x+9,b.y-7,5,4,'#b9db86');if(b.fuse<.2)rect(b.x+4,b.y+4,6,6,'#fff7c8');}
 for(const e of g.explosions){const radius=(1-e.life/.34)*108;ctx.globalAlpha=e.life/.34;ctx.strokeStyle='#eff8b7';ctx.lineWidth=5;ctx.beginPath();ctx.arc(e.x,e.y,radius,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=e.life/.34*.16;ctx.fillStyle='#daf79e';ctx.fill();}ctx.globalAlpha=1;
 for(const f of g.particles){ctx.globalAlpha=clamp(f.life/.3,0,1);rect(f.x,f.y,f.size,f.size,f.color);}ctx.globalAlpha=1;
 for(const f of g.texts){ctx.globalAlpha=clamp(f.life/.3,0,1);ctx.font='bold 14px Consolas,"Microsoft YaHei"';ctx.fillStyle='#30554b';ctx.fillText(f.text,f.x+1,f.y+1);ctx.fillStyle=f.color;ctx.fillText(f.text,f.x,f.y);}ctx.globalAlpha=1;
 ctx.restore();
 // Foreground leaves only occupy the extreme lower edge.
 for(let i=0;i<9;i++){const x=i*163-(camera*1.12%163);if(night)crystal(x,554,24,29);else bush(x,551,1.15);}
}
window.addEventListener('keydown',e=>{
 const active=['ArrowLeft','ArrowRight','ArrowUp','Space','KeyA','KeyD','KeyJ','KeyK','KeyL','Escape','KeyR'].includes(e.code);if(active&&e.target.tagName!=='INPUT')e.preventDefault();
 if(e.code==='Escape'&&!e.repeat)game.togglePause();
 if(e.code==='KeyR'&&!e.repeat&&['dead','won'].includes(game.state)){game.reset();game.start();}
 if(game.state==='playing'){if(e.code==='Space'&&!keys.has('Space')&&!e.repeat)game.requestJump();if(e.code==='KeyK'&&!e.repeat)game.dash();if(e.code==='KeyL'&&!e.repeat)game.throwBomb();keys.add(e.code);}
});
window.addEventListener('keyup',e=>{keys.delete(e.code);if(e.code==='Space'&&game.p.vy<-220)game.p.vy=-220;});
window.addEventListener('blur',()=>{keys.clear();if(game.state==='playing')game.togglePause();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&game.state==='playing')game.togglePause();});
$('pause').onclick=()=>game.togglePause();$('mute').onclick=()=>{muted=!muted;$('mute').innerHTML=muted?'♪ <span>声音关</span>':'♪ <span>声音开</span>';$('mute').setAttribute('aria-pressed',String(muted));$('mute').setAttribute('aria-label',muted?'开启声音':'静音');};
for(const button of document.querySelectorAll('[data-key]')){const key=button.dataset.key;button.addEventListener('pointerdown',e=>{e.preventDefault();button.setPointerCapture(e.pointerId);if(game.state!=='playing')return;keys.add(key);if(key==='Space')game.requestJump();if(key==='KeyK')game.dash();if(key==='KeyL')game.throwBomb();});const release=()=>{keys.delete(key);if(key==='Space'&&game.p.vy<-220)game.p.vy=-220;};button.addEventListener('pointerup',release);button.addEventListener('pointercancel',release);}
game=new Game();let uiTick=0;
function frame(ts){if(!last)last=ts;let dt=Math.min((ts-last)/1000,.1);last=ts;if(game.state==='playing'){accumulator+=dt;while(accumulator>=STEP){game.update(STEP);accumulator-=STEP;}}else{accumulator=0;if(game.state==='start')game.t+=dt;}draw(game);uiTick+=dt;if(uiTick>.08){game.renderUI();uiTick=0;}requestAnimationFrame(frame);}
requestAnimationFrame(frame);
// Explicit test mode allows deterministic physics checks without affecting normal play.
if(new URLSearchParams(location.search).has('test'))window.__gameTest={get game(){return game;},keys,step(n=1){for(let i=0;i<n;i++)game.update(STEP);game.renderUI();draw(game);},reset(){game.reset();game.start();},constants:{W,H,WORLD,STEP,GRAVITY,SPEED,JUMP,MAX_HP},draw:()=>draw(game)};
})();

